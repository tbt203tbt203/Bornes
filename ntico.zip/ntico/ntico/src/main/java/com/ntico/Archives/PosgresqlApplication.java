/*package com.ntico.postgresqlApplication;

import org.springframework.boot.SpringApplication;

public class PosgresqlApplication {
    public static void main(String[] args) {
        SpringApplication.run(PosgresqlApplication.class);
    }
}
*/