package com.ntico.Archives;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
/*
@Entity

public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String pseudo;

    private String email;

    private String statut;

    public Product(){

    }
    public Product(Long id, String pseudo, String email, String statut){
        this.id = id;
        this.pseudo = pseudo;
        this.email = email;
        this.statut = statut;

    }
    public Long getid() {
        return id;
    }

    public void setid(Long id) {
        this.id = id;
    }


    public String getpseudo() {
        return pseudo;
    }

    public void setpseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    public String getstatut() {
        return statut;
    }

    public void setstatut(String statut) {
        this.statut = statut;
    }
}*/
